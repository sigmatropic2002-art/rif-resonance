@echo off
setlocal
set "APP_DIR=%~dp0App Files\"
set "APP_URL=file:///%APP_DIR:\=/%index.html"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="%APP_URL%"
  exit /b 0
)

set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="%APP_URL%"
  exit /b 0
)

set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --app="%APP_URL%"
  exit /b 0
)

set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --app="%APP_URL%"
  exit /b 0
)

start "" "%APP_DIR%index.html"
exit /b 0
