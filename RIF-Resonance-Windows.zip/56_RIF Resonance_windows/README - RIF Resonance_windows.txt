RIF Resonance_windows — PORTABLE VERSION 3.1
=============================================

START
1. Keep all folders and files together.
2. Double-click "START RIF RESONANCE_windows.cmd".
3. Microsoft Edge or Google Chrome opens the player in a desktop-style window.
4. If the launcher is blocked, open "App Files", then double-click index.html.

This version requires no installation, account, or internet connection.

CONTENTS
- App Files — the complete offline player, editor, and 874-script library.
- Original Scripts — all 874 supplied original .rts files.
- My Custom Scripts — a convenient folder for scripts you export.

CUSTOM SCRIPTS
- Choose + New to create a script.
- Choose Save to library to keep it in this browser on this Windows account.
- Choose Save .rts to export the original script format.
- Move exported files from Downloads into My Custom Scripts if desired.
- Choose Import .rts to reopen an exported or original script.

SAFETY
This is an audio tool, not a medical device. It does not diagnose, treat, cure,
or prevent disease and is not a substitute for medical care. Begin at low volume.
Do not connect electrodes directly to a computer audio port.
