RIF RESONANCE — WINDOWS APP ONLY
================================

Frequency Audio for Relaxation and Well-Being

This download contains the RIF Resonance player and editor only.
It intentionally contains no frequency scripts.

START
1. Extract the complete ZIP folder.
2. Keep all included folders and files together.
3. Double-click "START RIF RESONANCE_windows.cmd".
4. Microsoft Edge or Google Chrome opens the player in an app-style window.

ADD YOUR PRIVATE SCRIPT LIBRARY
1. Save the .riflibrary attachment supplied to you by email.
2. In RIF Resonance, choose "Choose library from Files".
3. Select the supplied .riflibrary file.
4. The library is checked and stored only on this Windows account.

CUSTOM SCRIPTS
- Choose + New to create a script.
- Choose Save to library to store a custom script locally.
- Choose Save .rts to export a script.
- Choose Import .rts to reopen an exported script.

SAFETY
This software is an audio tool, not a medical device. It does not diagnose,
treat, cure, or prevent disease and is not a substitute for medical care.
Begin at low volume. Do not connect electrodes directly to a computer port.
