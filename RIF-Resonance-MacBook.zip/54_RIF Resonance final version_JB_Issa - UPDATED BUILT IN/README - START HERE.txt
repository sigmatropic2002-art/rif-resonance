RIF RESONANCE — PERSONAL BUILT-IN VERSION 4.5
=================================

Frequency Audio for Relaxation and Well-Being

This private personal edition keeps all 874 scripts built directly into the app.
It does not require a separate .riflibrary file.

LATEST CONTROLS
- Custom shows only scripts you created or imported.
- Select a custom script and choose Delete custom to remove it after confirmation.
- Preferences remembers volume, waveform, and run mode.
- Test output plays a short limited-volume test tone.
- Open Mac Sound Settings selects speakers, headphones, AirPods, or another output.

START
1. Keep every item inside this folder.
2. Double-click "OPEN RIF RESONANCE.command".
3. If macOS blocks it, Control-click it, choose Open, then choose Open again.

CONTENTS
- RIF Resonance.app — the complete native macOS player and script editor.
- Original Scripts — all 874 supplied original .rts files.
- My Custom Scripts — a convenient place for .rts files you create.
- OPEN RIF RESONANCE.command — verifies and opens the app.

CREATE OR SAVE A SCRIPT
1. In the app, choose + New.
2. Enter a script name and tone values.
3. Choose + Add tone for additional steps.
4. Choose Save to library to keep the custom script locally in the app.
5. Choose Save .rts file to export the original format.
6. In the Mac Save dialog, select the "My Custom Scripts" folder if desired.
7. To delete it later, choose Custom, select the script, then choose Delete custom.

ORIGINAL .RTS FORMAT
Each tone is saved as:
tone frequency duration phase left right

The last line is:
end

The app also supports Import .rts and creates editable copies of built-in scripts.
The built-in library contains corrected playable values for malformed legacy lines;
the untouched supplied originals remain available in the Original Scripts folder.

SAFETY
This software is an audio tool, not a medical device. It does not diagnose, treat,
cure, or prevent disease and is not a substitute for medical care. Begin at low
volume. Do not connect electrodes directly to a Mac audio port.
