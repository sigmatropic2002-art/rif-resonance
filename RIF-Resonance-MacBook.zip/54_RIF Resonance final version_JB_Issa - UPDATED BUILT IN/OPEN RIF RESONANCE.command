#!/bin/zsh
set -eu

final_folder=${0:A:h}
app="$final_folder/RIF Resonance.app"
native_executable="$app/Contents/MacOS/RIFResonance"
log_directory="$HOME/Library/Logs"
log_file="$log_directory/RIF Resonance.log"

show_error() {
  message="$1"
  /usr/bin/osascript -e "display alert \"RIF Resonance\" message \"$message\" as critical" 2>/dev/null || /bin/echo "$message"
}

if [[ ! -x "$native_executable" ]]; then
  show_error "RIF Resonance.app is missing or incomplete. Keep all files inside the final-version folder."
  exit 1
fi

if ! /usr/bin/codesign --verify --deep --strict "$app"; then
  show_error "The RIF Resonance app failed its integrity check."
  exit 1
fi

/bin/mkdir -p "$log_directory"
/usr/bin/xattr -cr "$app" 2>/dev/null || true
/usr/bin/codesign --force --deep --sign - --identifier com.rifresonance.native.frequency "$app"
/usr/bin/codesign --verify --deep --strict "$app"
"$native_executable" --self-test

if [[ "${RIF_SKIP_LAUNCH:-0}" == "1" ]]; then
  /bin/echo "RIF Resonance final-folder test passed."
  exit 0
fi

# Launch the real native executable directly. This avoids old cached launch data
# from previous copies of the app.
/usr/bin/nohup "$native_executable" >"$log_file" 2>&1 &
native_pid=$!
/bin/sleep 3

if /bin/kill -0 "$native_pid" 2>/dev/null; then
  /usr/bin/osascript -e 'display notification "RIF Resonance is open." with title "RIF Resonance"' 2>/dev/null || true
  exit 0
fi

# Emergency fallback: the same complete player can run locally in Safari.
index_file="$app/Contents/Resources/index.html"
if /usr/bin/open -a Safari "$index_file" || /usr/bin/open "$index_file"; then
  /usr/bin/osascript -e 'display notification "RIF Resonance opened in Safari." with title "RIF Resonance"' 2>/dev/null || true
  exit 0
fi

show_error "macOS could not display the app. The technical log is at $log_file"
exit 1
