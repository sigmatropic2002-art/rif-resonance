RIF Resonance
=============

Frequency Audio for Relaxation and Well-Being

Personal built-in version 4.5 includes all 874 supplied .rts frequency scripts
inside a searchable local interface. It does not require a separate library file.

INSTALL
1. Keep "INSTALL AND OPEN RIF RESONANCE.command" beside "RIF Resonance.app".
2. Double-click the command to install the app, create a Desktop shortcut, and open it.
3. If macOS asks for confirmation, Control-click the command and choose Open.

SHORTCUT
- The installer creates one Desktop shortcut to the copy in your personal Applications folder.
- You can also drag "RIF Resonance.app" to the Dock.

USE
- Search for a script in the left panel.
- Select a script and press Play sequence.
- Original timing uses the durations stored in the supplied .rts files.
- 5-second preview runs each step for at most five seconds.
- Start with the master volume low and use Stop to end playback.

CUSTOM SCRIPTS
- Choose + New to build a script with frequency, duration, phase, left, and right values.
- Choose Save to library to keep a custom script in the app on this Mac.
- Choose Save .rts to export the original format: "tone frequency duration phase left right", followed by "end".
- Choose Import .rts to open an original script file for review and saving.
- Built-in scripts are protected; Edit copy creates an editable custom copy.
- Custom shows only user-created or imported scripts.
- Delete custom removes the selected custom script after Mac confirmation.

PREFERENCES AND OUTPUT
- Preferences saves the default volume, waveform, and run mode.
- Test output plays a one-second, limited-volume tone.
- Open Mac Sound Settings selects the Mac audio-output device.

COMPATIBILITY NOTES
- The original .exe and .lnk files are Windows Intel files and cannot be converted byte-for-byte into a modern Apple-silicon application.
- This replacement runs locally and does not require Windows, Wine, an account, or an internet connection.
- Frequencies above 20,000 Hz are outside the reliable Mac audio-output range and are kept as silent sequence steps. The app identifies them so they can be skipped.
- Very low frequencies may not be reproduced by normal speakers or headphones.

SAFETY
This software is an audio tool, not a medical device. It does not diagnose, treat, cure, or prevent any disease and is not a substitute for professional medical advice. Start at low volume. Do not connect electrodes directly to a Mac audio port.
