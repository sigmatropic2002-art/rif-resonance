RIF RESONANCE CUSTOMER — MACBOOK BUYER EDITION
Version 5.0 (Build 20)

SYSTEM REQUIREMENTS
- macOS 12 Monterey or newer
- Apple Silicon or Intel Mac
- One purchased license per device

INSTALLATION
1. Double-click the downloaded ZIP file to extract this folder.
2. Drag “RIF Resonance Customer.app” into the Applications folder.
3. Open the app from Applications.
4. If macOS says the developer cannot be verified, Control-click the app, choose Open, then choose Open again. Only use the package received from the official RIF Resonance download page.

ACTIVATION
1. Open RIF Resonance Customer.
2. The app displays this Mac’s MID and Site Code.
3. Send the MID, Site Code, purchase/order information, and buyer email address to the seller.
4. The seller will email a unique signed .riflicense file for this device.
5. In the app, choose Import License and select that .riflicense file.

SCRIPT LIBRARY
- No frequency script or script library is included in this download.
- The script library is supplied separately by email after purchase.
- When received, use the app’s Import Script/Library control to select the authorized .riflibrary file.
- Keep the license and script library files private. They are intended only for the licensed buyer and device.

PACKAGE CONTENTS
- RIF Resonance Customer.app
- This installation and activation guide

SECURITY
- This buyer edition requires a valid digitally signed RIF Resonance license.
- A license is bound to one device using the MID/Site Code.
- Do not accept license or script files from unauthorized sources.

IMPORTANT WELLNESS NOTICE
RIF Resonance provides audio-frequency tools for relaxation and general well-being. It is not a medical device and does not diagnose, treat, cure, or prevent disease. It is not a substitute for professional medical care. Stop use if you feel unwell, and consult a qualified clinician about health concerns.

Copyright © 2026 RIF Resonance. All rights reserved.
